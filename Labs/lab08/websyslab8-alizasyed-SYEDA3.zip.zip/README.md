Aliza Syed Web Sys Lab 08


During this lab, I learned how to create and modify tables in a MySQL database, insert data, and establish foreign key relationships to maintain data integrity. Writing SQL queries to sort, filter, and aggregate data helped me understand how relational databases organize and link information. I also realized the importance of matching data types and column names exactly, especially when using joins or foreign keys. Overall, this lab improved my skills in managing databases and using SQL effectively for data analysis.